# Scheduled Popup & Notice Pro 2.0 - OpenCart 4.0.x

This archive is built specifically for OpenCart 4.0.x. Do not install it on another OpenCart generation.

## Install

1. Upload the .ocmod.zip through Extensions > Installer.
2. Open Extensions > Extensions > Modules.
3. Install and edit Scheduled Popup & Notice Pro.
4. Enable the module, configure a campaign, and save.

This package uses native OpenCart events. No OCMOD refresh is required.

## Included Pro features

- Up to 50 simultaneous campaigns with priority and sequential display.
- One-time, weekly, and monthly schedules with timezone.
- Per-language popup and order-email content.
- Dynamic schedule shortcodes.
- Custom image upload with automatic WebP optimization, design presets, colors, overlay, and blur.
- Countdown, configurable CTA, category/product targeting, and aggregate statistics.
- Safe cache clear and automatic migration from 1.x settings.

The module is disabled on first install. It contains no store credentials, customer data, domain, branding, or enabled campaign.
